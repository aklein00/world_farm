import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import * as THREE from '../vendor/three/build/three.module.js';
import {variants,recipe,roles} from './recipes.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const all=variants.map(recipe);fs.writeFileSync(root+'/src/recipes.json',JSON.stringify(all,null,2));
if(process.argv.includes('--recipes'))process.exit(0);
function box(p,segs){const [w,h,d]=p.s,b=p.bevel;if(!b)return new THREE.BoxGeometry(w,h,d).toNonIndexed();const x=w/2-b,y=h/2-b,s=new THREE.Shape();s.moveTo(-x,-y);s.lineTo(x,-y);s.lineTo(x,y);s.lineTo(-x,y);s.closePath();const g=new THREE.ExtrudeGeometry(s,{depth:d-2*b,bevelEnabled:true,bevelSegments:segs,steps:1,bevelSize:b,bevelThickness:b,curveSegments:1});g.translate(0,0,-d/2+b);return g;}
function polygonMesh(vertices, faces) {
  const positions = [];
  for (const face of faces) {
    for (let i = 1; i < face.length - 1; i += 1) {
      for (const index of [face[0], face[i], face[i + 1]]) positions.push(...vertices[index]);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.computeVertexNormals();
  return geometry;
}

function hip(part) {
  const [w, h, d] = part.s;
  const [tx, tz] = part.taper;
  const vertices = [
    [-w/2,-h/2,-d/2], [w/2,-h/2,-d/2], [w/2,-h/2,d/2], [-w/2,-h/2,d/2],
    [-w*tx,h/2,-d*tz], [w*tx,h/2,-d*tz], [w*tx,h/2,d*tz], [-w*tx,h/2,d*tz],
  ];
  return polygonMesh(vertices, [[1,2,3,0],[7,6,5,4],[4,5,1,0],[5,6,2,1],[6,7,3,2],[7,4,0,3]]);
}
function createNativeModel(r){const group=new THREE.Group();group.name=r.id+' '+r.name;for(const p of r.parts){const g=p.type==='mesh'?polygonMesh(p.vertices,p.faces):p.type==='hip'?hip(p):box(p,r.bevelSegments);const pos=g.attributes.position,normal=g.attributes.normal;const uv=[];const tile=roles.indexOf(p.mat);for(let i=0;i<pos.count;i++){const n=[normal.getX(i),normal.getY(i),normal.getZ(i)].map(Math.abs);const axis=n.indexOf(Math.max(...n));const a=axis===0?2:0,c=axis===1?2:1;const xyz=[pos.getX(i),pos.getY(i),pos.getZ(i)];const u=xyz[a]/p.s[a]+.5,v=xyz[c]/p.s[c]+.5;uv.push((tile%4+.1+u*.8)/4,(Math.floor(tile/4)+.1+(1-v)*.8)/2);}g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({name:p.mat,roughness:p.mat==='glass'?.3:.78}));m.name=p.name;m.position.fromArray(p.p);m.rotation.x=p.rx||0;group.add(m);}group.updateMatrixWorld(true);return group;}
function exportGLB(model,r){const chunks=[],views=[],accessors=[];let bytes=0;const append=(data,target)=>{const b=Buffer.from(data.buffer??data,data.byteOffset??0,data.byteLength??data.length);const id=views.length;views.push({buffer:0,byteOffset:bytes,byteLength:b.length,...(target?{target}:{})});chunks.push(b);bytes+=b.length;const pad=(4-bytes%4)%4;if(pad){chunks.push(Buffer.alloc(pad));bytes+=pad;}return id;};
 const acc=(data,size,type,min,max)=>{const index=accessors.length;accessors.push({bufferView:append(data,34962),componentType:5126,count:data.length/size,type,...(min?{min,max}:{})});return index;};
 const meshes=[],nodes=[];let total=0;
 for(const role of roles){const positions=[],normals=[],uvs=[];model.traverse(m=>{if(!m.isMesh||m.material.name!==role)return;const g=m.geometry.clone().applyMatrix4(m.matrixWorld);positions.push(...g.attributes.position.array);normals.push(...g.attributes.normal.array);uvs.push(...g.attributes.uv.array);});if(!positions.length)continue;const min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];for(let i=0;i<positions.length;i++){const a=i%3;min[a]=Math.min(min[a],positions[i]);max[a]=Math.max(max[a],positions[i]);}const attributes={POSITION:acc(new Float32Array(positions),3,'VEC3',min,max),NORMAL:acc(new Float32Array(normals),3,'VEC3'),TEXCOORD_0:acc(new Float32Array(uvs),2,'VEC2')};meshes.push({name:role,primitives:[{attributes,material:roles.indexOf(role),mode:4}]});nodes.push({name:r.id+' / '+role,mesh:meshes.length-1});total+=positions.length/9;}
 const img=append(fs.readFileSync(root+'/textures/'+r.id+'-atlas.png'));
 const materials=roles.map(role=>({name:role,pbrMetallicRoughness:{baseColorTexture:{index:0},metallicFactor:0,roughnessFactor:role==='glass'?.32:.78},...(role==='glow'&&r.emissive?{emissiveFactor:[1,.47,.12],emissiveTexture:{index:0}}:{})}));
 const gltf={asset:{version:'2.0',generator:'WorldFarm native Three.js r181 builder'},scene:0,scenes:[{nodes:[nodes.length]}],nodes:[...nodes,{name:model.name,children:nodes.map((_,i)=>i),extras:{units:'meters',front:'+Z',source:'native Three.js',variant:r.id}}],meshes,materials,textures:[{source:0,sampler:0}],samplers:[{magFilter:9729,minFilter:9987,wrapS:33071,wrapT:33071}],images:[{name:r.id+' embedded atlas',mimeType:'image/png',bufferView:img}],accessors,bufferViews:views,buffers:[{byteLength:bytes}]};
 let json=Buffer.from(JSON.stringify(gltf));json=Buffer.concat([json,Buffer.alloc((4-json.length%4)%4,32)]);const bin=Buffer.concat(chunks);const header=Buffer.alloc(12);header.writeUInt32LE(0x46546c67);header.writeUInt32LE(2,4);header.writeUInt32LE(12+8+json.length+8+bin.length,8);const jh=Buffer.alloc(8);jh.writeUInt32LE(json.length);jh.writeUInt32LE(0x4e4f534a,4);const bh=Buffer.alloc(8);bh.writeUInt32LE(bin.length);bh.writeUInt32LE(0x004e4942,4);const out=Buffer.concat([header,jh,json,bh,bin]);fs.writeFileSync(root+'/threejs/'+r.id+'-market-threejs.glb',out);return {variant:r.id,name:r.name,triangles:total,drawCalls:meshes.length,bytes:out.length,embeddedImages:1};}
const stats=[];for(const r of all)stats.push(exportGLB(createNativeModel(r),r));fs.writeFileSync(root+'/threejs/stats.json',JSON.stringify(stats,null,2));console.log(stats);
